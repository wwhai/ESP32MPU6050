/*
 * File: minOrMax.h
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 26-Apr-2023 21:56:05
 */

#ifndef MINORMAX_H
#define MINORMAX_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void maximum(const double x[5], double *ex, int *idx);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for minOrMax.h
 *
 * [EOF]
 */
