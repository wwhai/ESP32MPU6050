/*
 * File: ActionRecognize_data.h
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 26-Apr-2023 21:56:05
 */

#ifndef ACTIONRECOGNIZE_DATA_H
#define ACTIONRECOGNIZE_DATA_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

/* Variable Declarations */
extern const double dv[5];
extern boolean_T isInitialized_ActionRecognize;

#endif
/*
 * File trailer for ActionRecognize_data.h
 *
 * [EOF]
 */
