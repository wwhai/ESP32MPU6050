/*
 * File: ActionRecognize_data.c
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 26-Apr-2023 21:56:05
 */

/* Include Files */
#include "ActionRecognize_data.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
const double dv[5] = {0.24298504707402621, 0.25835333210263983,
                      0.22410928558242571, 0.16434373269337271,
                      0.11020860254753553};

boolean_T isInitialized_ActionRecognize = false;

/*
 * File trailer for ActionRecognize_data.c
 *
 * [EOF]
 */
