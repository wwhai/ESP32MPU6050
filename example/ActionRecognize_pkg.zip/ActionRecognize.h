/*
 * File: ActionRecognize.h
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 26-Apr-2023 21:56:05
 */

#ifndef ACTIONRECOGNIZE_H
#define ACTIONRECOGNIZE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern double ActionRecognize(const double X[60]);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for ActionRecognize.h
 *
 * [EOF]
 */
