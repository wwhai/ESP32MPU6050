/*
 * File: ActionRecognize_initialize.h
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 26-Apr-2023 21:56:05
 */

#ifndef ACTIONRECOGNIZE_INITIALIZE_H
#define ACTIONRECOGNIZE_INITIALIZE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void ActionRecognize_initialize(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for ActionRecognize_initialize.h
 *
 * [EOF]
 */
