/*
 * File: ActionRecognize_terminate.h
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 26-Apr-2023 21:56:05
 */

#ifndef ACTIONRECOGNIZE_TERMINATE_H
#define ACTIONRECOGNIZE_TERMINATE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void ActionRecognize_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for ActionRecognize_terminate.h
 *
 * [EOF]
 */
