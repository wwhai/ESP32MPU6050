/*
 * File: ActionRecognize_types.h
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 26-Apr-2023 21:56:05
 */

#ifndef ACTIONRECOGNIZE_TYPES_H
#define ACTIONRECOGNIZE_TYPES_H

/* Include Files */
#include "rtwtypes.h"

#endif
/*
 * File trailer for ActionRecognize_types.h
 *
 * [EOF]
 */
